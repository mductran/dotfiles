# CHANGELOG: wayland-protocols-wlr

## Unreleased

## 0.1.0 -- 27/12/2022

## 0.1.0-beta.14

### Additions

- Update wlr-protocols
  - `wlr-output-management-unstable-v1` is now version 4, allowing to change the adaptive sync state
